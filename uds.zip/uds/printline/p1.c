#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>

char path[]="mysocket";

void main()
{

	//unix socket---------------------------------------------------------------------------------------------------
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	int fd=2;
	if(usfd<0)
	{
		perror("usfd\n");
		exit(-1);
	}
	struct sockaddr_un mypath,client;
	mypath.sun_family=AF_UNIX;
	strcpy(mypath.sun_path,path);
	unlink(path);
	if(bind(usfd,(struct sockaddr*)&mypath,sizeof(mypath))<0)
	{
		perror("bind\n");
		exit(-1);
	}

	listen(usfd,4);
	printf("waiting .......\n");
	int clen=sizeof(client);
	int nusfd=accept(usfd,(struct sockaddr*)&client,&clen);
	if(nusfd<0)
	{
		perror("accept\n");
		exit(-1);
	}
	//--------------------------------------------------
	char buf[2];
	char ctr_buf[CMSG_SPACE(sizeof(int))];
	struct msghdr mhdr;
	struct cmsghdr *cmhdr=NULL;
	struct iovec miov[1];
	struct msghdr mhdr2;
	//--------------------------
	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;
	//--------------------------
	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	//------------------------
	 mhdr.msg_control=ctr_buf;
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));

	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));
	//--------------------
	 mhdr.msg_flags=0;

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}
	//--------------------------------
	printf("waiting for client to write.......\n");
 
	if(recvmsg(nusfd,&mhdr,0)<0)
	{
		perror("recv\n");
		exit(-1);
	}
	else printf("fd received\n");
	 fd=*(int*)CMSG_DATA(CMSG_FIRSTHDR(&mhdr));
	FILE *ptr=fdopen(fd,"r");
	printf("fd==%d",fd);
	printf("server......\n");
	int n;
	char *buff=NULL;
	size_t len=0;
	 n=atoi(buf);
	 char lin[10];
	while(1)
	{
	       
		int i=0;
		while(i<n)
		{
			if(getline(&buff,&len,ptr)!=-1)
			{
				printf("%s\n",buff);
			}
			else break;
			i++;
		}
		if(i<n)
		  {
		  	printf("----------------------END OF THE FILE---------------------------\n");
		  	break;
		  }
		printf("how many lines do u want to print other process\n");
		scanf("%s",lin);
		if(send(nusfd,lin,sizeof(lin),0)<=0)
		{
			perror("send2\n");
			exit(-1);
		}
		else printf("p1 is informed\n");
		printf("let me know no mof line p2\n");
		if(recv(nusfd,lin,sizeof(lin),0)<=0)
		{
			perror("recv\n");
			exit(-1);
		}
		else printf("fd received n=%s\n",lin);
		n=atoi(lin);
	}	

}