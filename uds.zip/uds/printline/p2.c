#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>

char path[]="mysocket";

void main()
{
	//unix socket
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	{
		perror("usfd\n");
		exit(-1);
	}
	struct sockaddr_un mypath,serv;

	serv.sun_family=AF_UNIX;
	strcpy(serv.sun_path,path);

	if(connect(usfd,(struct sockaddr*)&serv,sizeof(serv))<0)
	{
		perror("connet\n");
		exit(-1);
	}
	else printf("connected\n");
	//open file
	FILE* ptr=fopen("myfile.txt","r");
	int fd=fileno(ptr);
	printf("fd==%d\n",fd );
	char *bu=NULL;
	size_t l=0;

	if(ptr==NULL||fd<0)
	{
		perror("fd\n");
		exit(-1);
	}
	//--------------------------
	 char buf[2]="3";
	 char ctr_buf[CMSG_SPACE(sizeof(int))];

	struct msghdr mhdr;
	struct cmsghdr *cmhdr=NULL;
	struct iovec miov[1];
	//--------------------------
	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;
	//--------------------------
	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	//------------------------
	 mhdr.msg_control=ctr_buf;
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));

	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}
	//--------------------
	 mhdr.msg_flags=0;
	 
	
	 //------------------------------------------------------------------------------------------------------
	if(sendmsg(usfd,&mhdr,0)<0)
	{
		perror("SEND FD\n");
		exit(-1);
	}
	else printf("sent fd\n");

	int n;
	char *buff=NULL;
	size_t len=0;
	char lin[10];
	if(ftell(ptr)<0)
			{
				perror("fd closed\n");
				exit(-1);
			}
			else 
				{
					printf("%ld\n", ftell(ptr));
					fseek(ptr,0,SEEK_SET);
				}
	printf("waiting..........\n");
	while(1)
	{
		printf("let me know no mof line p1\n");

		if(recv(usfd,lin,sizeof(lin),0)<0)
		{
			perror("terminated\n");
			exit(-1);
		}
		else printf("received\n");
		n=atoi(lin);
	 	printf("n=%d\n",n);
		int i=0;
		int c;

		while(i<n)
		{
			if((c=getline(&buff,&len,ptr))!=-1)
			{
				printf("%s\n",buff);
			}
			else 
				{
					perror("getline\n");
					printf("%d\n", c);
					break;
				}
			i++;
		}
		if(i<n)
		  {
		  	printf("----------------------END OF THE FILE---------------------------\n");
		  	break;
		  }

		printf("how many lines do u want to print other process\n");
		scanf("%s",lin);
		if(send(usfd,lin,sizeof(lin),0)<=0)
		{
			perror("sned2\n");
			exit(-1);
		}
		else printf("p1 is informed\n");
		
	}	
	       free(buff);
           fclose(ptr);
           exit(EXIT_SUCCESS);

	return ;
}