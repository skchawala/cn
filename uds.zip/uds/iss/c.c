#include<stdio.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<stdlib.h>

int getconnect()
{
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);

	struct sockaddr_in saddr;
	saddr.sin_family=AF_INET;
	saddr.sin_port=htons(45555);
	saddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(connect(sfd,(struct sockaddr*)&saddr,sizeof(saddr))<0)
	{
		perror("getconnect-connect\n");
		return -1;
	}
	else 
	{
		return sfd;
	}
}

int main()
{
	
	char buff[100];
	int d;
	int sfd=getconnect();
	if(sfd<0)
	{
		perror("sfd-not-found\n");
		exit(-1);
	}

	printf("waiting..........\n");
	while(1)
	{
		if((d=recv(sfd,buff,sizeof(buff),0))<=0)
			{
				printf("recv=%d",d);
				break;
			}
		 printf("c-received:%s\n",buff);
	}
	return 0;
}
