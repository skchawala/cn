#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>
#include<signal.h>

	char path[]="mysocket";
	int usfd;

int recvfd(int usfd)
{
	char buf[2]="3";
	char ctr_buf[CMSG_SPACE(sizeof(int))];
	int fd=2;
	struct msghdr mhdr;
	struct iovec miov[1];
	struct cmsghdr *cmhdr=NULL;
	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;

	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	 mhdr.msg_control=ctr_buf;
	  
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	if(cmhdr==NULL)
	{

	  perror("cmhdr\n");
	  exit(-1);
	}
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));
  
	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	 
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}
	 mhdr.msg_flags=0;

	 if(recvmsg(usfd,&mhdr,0)<0)
		{
			perror("recv\n");
		    return -1;
		}
	else 
		{
			
			fd=*(int*)CMSG_DATA(CMSG_FIRSTHDR(&mhdr));
			return fd;
		}

}

int  ugetconnect()
{
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	{
		perror("ugetconnect-usfd\n");
		 return -1;
	}

	struct sockaddr_un mypath,serv;

	serv.sun_family=AF_UNIX;
	strcpy(serv.sun_path,path);

	if(connect(usfd,(struct sockaddr*)&serv,sizeof(serv))<0)
	{
		perror("ugetconnect-connet\n");
		return -1;
	}
	else
	{
		return usfd;
	}

}


void* funct(void* args)
{
	int fd=atoi((char*)args);
	char buff[100]="i am sub-server";
	while(1)
	{
		if(send(fd,buff,sizeof(buff),0)<=0)
		{
			perror("send-error");
			 break;
		}
		else
		{
			printf("sent-msg\n");
		}
		sleep(5);
	}

}
void handler(int  signum)
{
	char fd_arg[5];
	int fd=recvfd(usfd);
	if(fd<0)
	{
		perror("fd-not-recvd\n");
		return ;
	}
	else
	{
		sprintf(fd_arg,"%d",fd);
	}

	 pthread_t thread;

	if(pthread_create(&thread,NULL,funct,fd_arg)<0)
	{
		perror("thread-not -created\n");
		return;
	}
	else 
	{
		printf("thread-started\n");
		return ;
	}
}

void main()
{
	 signal(SIGTSTP,handler);
	  usfd=ugetconnect();
		if(usfd<0)
		{
			perror("usfd-error\n");
			exit(-1);
		}
	else 
	{
		printf("unixsocket-connection-completed\n");
	}
	
	printf("s is started..........\n");
	while(1)
	{

	}
}