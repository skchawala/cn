#include<stdio.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<stdlib.h>

int getconnect(int port)
{
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);

	struct sockaddr_in saddr;
	saddr.sin_family=AF_INET;
	saddr.sin_port=htons(port);
	saddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(connect(sfd,(struct sockaddr*)&saddr,sizeof(saddr))<0)
	{
		perror("getconnect-connect\n");
		return -1;
	}
	else 
	{
		return sfd;
	}
}

int main()
{
	
	char buff[100];
	int d;
	int tis_port=45555;
	int s_port;

	int sfd=getconnect(tis_port);
	if(sfd<0)
	{
		perror("sfd-not-found\n");
		exit(-1);
	}
	if(recv(sfd,buff,sizeof(buff),0)<0)
	{
		perror("sfd\n");
		exit(-1);
	}
	else
	{
		s_port=atoi(buff);
		printf("port:%d recvd\n",s_port);
		close(sfd);
	}
	sfd=getconnect(s_port);

	printf("wating..........\n");
	while(1)
	{
		if((d=recv(sfd,buff,sizeof(buff),0))<=0)
			{
				printf("recv=%d",d);
				break;
			}
		 printf("c-received:%s\n",buff);
	}
	return 0;
}
