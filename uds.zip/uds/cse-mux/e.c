#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/poll.h>

#define mx_client 1

char path[]="socketse";

int getusfd()
{
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	{
		perror("getusfd-usfd\n");
		return -1;
	}

	struct sockaddr_un mypath;
	mypath.sun_family=AF_UNIX;
	strcpy(mypath.sun_path,path);
	unlink(path);
	if(bind(usfd,(struct sockaddr*)&mypath,sizeof(mypath))<0)
	{
		perror("getusfd-bind\n");
		return -1;
	}
	if(listen(usfd,4)<0)
	{
		perror("getusfd-listen\n");
		return -1;
	}
	else
	{
		return usfd;
	}
}


int getsfd(int port)
{
	//---------------------------------------------------------------------------------------------------------
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sfd<0)
	{
		perror("getsfd-sfd\n");
		return -1;
	}
	struct sockaddr_in myaddr;
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(port);
	myaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(bind(sfd,(struct sockaddr*)&myaddr,sizeof(myaddr))<0)
	{
		perror("getsfd-bind\n");
		return -1;
	}
	if(listen(sfd,2)<0)
	{
		perror("getsfd-listen\n");
		return -1;
	}
	else
	{
		return sfd;
	}
}

int recvfd(int usfd)
{
	char buf[2]="3";
	char ctr_buf[CMSG_SPACE(sizeof(int))];
	int fd=2;
	struct msghdr mhdr;
	struct iovec miov[1];
	struct cmsghdr *cmhdr=NULL;
	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;

	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	 mhdr.msg_control=ctr_buf;
	  
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	if(cmhdr==NULL)
	{

	  perror("cmhdr\n");
	  exit(-1);
	}
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));
  
	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	 
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}
	 mhdr.msg_flags=0;

	 if(recvmsg(usfd,&mhdr,0)<0)
		{
			perror("recv\n");
		    return -1;
		}
	else 
		{
			
			fd=*(int*)CMSG_DATA(CMSG_FIRSTHDR(&mhdr));
			return fd;
		}

}


void main()
{
		int usfd,sfd,nusfd,nsfd;
		int tis_pid;
		int client_port=45668;  //for accepting client
	    usfd=getusfd();
		sfd=getsfd(client_port);

	    printf("waiting for s-server.......\n");
	     nusfd=accept(usfd,NULL,NULL);
		if(nusfd<0)
		{
			perror("s-server-not-accepted\n");
			exit(-1);
		}
		else printf("s-server-accepted\n");
		int count=0;
		//get tis pid
		char buff[100];
		 nsfd=accept(sfd,NULL,NULL);
		 if(recv(nsfd,buff,sizeof(buff),0)<0)
			{
				perror("recv-error\n");
				exit(-1);
			}
		 else
		 {
		 	 close(nsfd);
		 	 tis_pid=atoi(buff);	
		 	printf("tis_pid recvd\n");
		 }
			
		struct pollfd fds[2];
		fds[0].fd=nusfd;
		fds[0].events=POLLIN;
		fds[1].fd=sfd;
		fds[1].events=POLLIN;

		while(1)
		{
			int temp=poll(fds,2,5);
			if(temp>0)
			{
					 
					if(fds[0].revents&POLLIN)
					{
						printf("server-s has sent fd\n");
						if(count>=mx_client)
						{
							nsfd=recvfd(fds[0].fd);

							kill(tis_pid,SIGTSTP);
							printf("sent signal to tis server notifying that no seat available\n");
						}
						else
						{
							nsfd=recvfd(fds[0].fd);
							count++;
							printf("seat allocated1\n");
						}	
					}
					if(fds[1].revents&POLLIN)
					{
						printf("client has reached\n");
						nsfd=accept(fds[1].fd,NULL,NULL);
						if(count>=mx_client)
						{
							kill(tis_pid,SIGTSTP);
							printf("sent signal to tis server notifying that no seat available2\n");
						}
						else
						{
							count++;
							printf("seat allocated\n");
						}	
					}
			
			}
			
		}


}