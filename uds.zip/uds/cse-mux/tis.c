#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>
#include<signal.h>

int getsfd()
{
	//---------------------------------------------------------------------------------------------------------
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sfd<0)
	{
		perror("getsfd-sfd\n");
		return -1;
	}
	struct sockaddr_in myaddr;
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(45555);
	myaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(bind(sfd,(struct sockaddr*)&myaddr,sizeof(myaddr))<0)
	{
		perror("getsfd-bind\n");
		return -1;
	}
	if(listen(sfd,4)<0)
	{
		perror("getsfd-listen\n");
		return -1;
	}
	else
	{
		return sfd;
	}
}

int getconnect()
{
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);

	struct sockaddr_in saddr;
	saddr.sin_family=AF_INET;
	saddr.sin_port=htons(45668);
	saddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(connect(sfd,(struct sockaddr*)&saddr,sizeof(saddr))<0)
	{
		perror("getconnect-connect\n");
		return -1;
	}
	else 
	{
		return sfd;
	}
}


void handler(int signum)
{
	printf("no seat available\n");
	while(1)
	{

	}
}

void main()
{
		signal(SIGTSTP,handler);

		int sfd,sfd2;
		sfd=getsfd();
		sfd2=getconnect();
		char buff[100];
		int pid=getpid();
		sprintf(buff,"%d",pid);
		if(send(sfd2,buff,sizeof(buff),0)<0)
		{
			perror("sfd2\n");
			exit(-1);
		}
		else
		{
			printf("sent tis_pid to sever-e\n");
			close(sfd2);
		}

		char cport[10]="45666";

		while(1)
		{
			int nsfd=accept(sfd,NULL,NULL);

			printf("client-accepted\n");

			if(send(nsfd,cport,sizeof(cport),0)<0)
			{
				perror("port not sent\n");
				exit(-1);
			}
			else printf("port-sent\n");
		}

}