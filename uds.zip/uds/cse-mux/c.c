#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/poll.h>

#define mx_client 2

char path[]="socketcs";

int  ugetconnect()
{
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	{
		perror("ugetconnect-usfd\n");
		 return -1;
	}

	struct sockaddr_un mypath,serv;

	serv.sun_family=AF_UNIX;
	strcpy(serv.sun_path,path);

	if(connect(usfd,(struct sockaddr*)&serv,sizeof(serv))<0)
	{
		perror("ugetconnect-connet\n");
		return -1;
	}
	else
	{
		return usfd;
	}

}

int getsfd()
{
	//---------------------------------------------------------------------------------------------------------
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sfd<0)
	{
		perror("getsfd-sfd\n");
		return -1;
	}
	struct sockaddr_in myaddr;
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(45666);
	myaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(bind(sfd,(struct sockaddr*)&myaddr,sizeof(myaddr))<0)
	{
		perror("getsfd-bind\n");
		return -1;
	}
	if(listen(sfd,2)<0)
	{
		perror("getsfd-listen\n");
		return -1;
	}
	else
	{
		return sfd;
	}
}

int sendfd(int usfd,int fd)
{
	char buf[2];
	char ctr_buf[CMSG_SPACE(sizeof(int))];
	struct msghdr mhdr;
	struct cmsghdr *cmhdr=NULL;
	struct iovec miov[1];
	struct msghdr mhdr2;

	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;
	
	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	
	mhdr.msg_control=ctr_buf;
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));

	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));
	//--------------------
	 mhdr.msg_flags=0;

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}

	if(sendmsg(usfd,&mhdr,0)<=0)
		{
			perror("SEND FD\n");
			 return -1;
		}
		else 
		{
			return 1;
		}

}

void main()
{
		int usfd,sfd,nsfd;
	    usfd=ugetconnect();
	    if(usfd<0)
		{
			perror("c-server-not-accepted\n");
			exit(-1);
		}
		else printf("c-server-accepted\n");

		sfd=getsfd();
		if(sfd<0)
		{
			perror("c-client-not-accepted\n");
			exit(-1);
		}
		else printf("c-client-accepted\n");

		int count=0;
		while(1)
		{
			 nsfd=accept(sfd,NULL,NULL);
			printf("client-accepted\n");
			if(count>=mx_client)
			{
				
				if(sendfd(usfd,nsfd)<0)
				{
					perror("fd not sent\n");
					exit(-1);
				}
				else printf("fd-sent\n");
			}
			else
			{
				count++;
				printf("seat allocated\n");
			}
			
		}
}