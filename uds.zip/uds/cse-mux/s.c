#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/un.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<string.h>
#include<stdlib.h>
#include<signal.h>
#include<sys/poll.h>

#define mx_client 1

char path[]="socketcs";
char path2[]="socketse";
int getusfd()
{
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	{
		perror("getusfd-usfd\n");
		return -1;
	}

	struct sockaddr_un mypath;
	mypath.sun_family=AF_UNIX;
	strcpy(mypath.sun_path,path);
	unlink(path);
	if(bind(usfd,(struct sockaddr*)&mypath,sizeof(mypath))<0)
	{
		perror("getusfd-bind\n");
		return -1;
	}
	if(listen(usfd,4)<0)
	{
		perror("getusfd-listen\n");
		return -1;
	}
	else
	{
		return usfd;
	}
}

int  ugetconnect()
{
	int usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	{
		perror("ugetconnect-usfd\n");
		 return -1;
	}

	struct sockaddr_un mypath,serv;

	serv.sun_family=AF_UNIX;
	strcpy(serv.sun_path,path2);

	if(connect(usfd,(struct sockaddr*)&serv,sizeof(serv))<0)
	{
		perror("ugetconnect-connet\n");
		return -1;
	}
	else
	{
		return usfd;
	}

}


int getsfd()
{
	//---------------------------------------------------------------------------------------------------------
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sfd<0)
	{
		perror("getsfd-sfd\n");
		return -1;
	}
	struct sockaddr_in myaddr;
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(45667);
	myaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	if(bind(sfd,(struct sockaddr*)&myaddr,sizeof(myaddr))<0)
	{
		perror("getsfd-bind\n");
		return -1;
	}
	if(listen(sfd,2)<0)
	{
		perror("getsfd-listen\n");
		return -1;
	}
	else
	{
		return sfd;
	}
}

int sendfd(int usfd,int fd)
{
	char buf[2];
	char ctr_buf[CMSG_SPACE(sizeof(int))];
	struct msghdr mhdr;
	struct cmsghdr *cmhdr=NULL;
	struct iovec miov[1];
	struct msghdr mhdr2;

	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;
	
	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	
	mhdr.msg_control=ctr_buf;
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));

	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));
	//--------------------
	 mhdr.msg_flags=0;

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}

	if(sendmsg(usfd,&mhdr,0)<=0)
		{
			perror("SEND FD\n");
			 return -1;
		}
		else 
		{
			return 1;
		}

}

int recvfd(int usfd)
{
	char buf[2]="3";
	char ctr_buf[CMSG_SPACE(sizeof(int))];
	int fd=2;
	struct msghdr mhdr;
	struct iovec miov[1];
	struct cmsghdr *cmhdr=NULL;
	mhdr.msg_name=NULL;
	mhdr.msg_namelen=0;

	miov[0].iov_base=buf;
	miov[0].iov_len=sizeof(buf);
	mhdr.msg_iov=miov;
	mhdr.msg_iovlen=1;
	 mhdr.msg_control=ctr_buf;
	  
	cmhdr=CMSG_FIRSTHDR(&mhdr);
	if(cmhdr==NULL)
	{

	  perror("cmhdr\n");
	  exit(-1);
	}
	cmhdr->cmsg_type=SCM_RIGHTS;
	cmhdr->cmsg_level=SOL_SOCKET;
	cmhdr->cmsg_len=CMSG_LEN(sizeof(int));
  
	mhdr.msg_controllen=CMSG_SPACE(sizeof(int));

	 if(CMSG_DATA(CMSG_FIRSTHDR(&mhdr))!=NULL)
	 
	  *(int *)CMSG_DATA(CMSG_FIRSTHDR(&mhdr))=fd; 
	else 
	{
		perror("no cmhdr\n");
		exit(-1);
	}
	 mhdr.msg_flags=0;

	 if(recvmsg(usfd,&mhdr,0)<0)
		{
			perror("recv\n");
		    return -1;
		}
	else 
		{
			
			fd=*(int*)CMSG_DATA(CMSG_FIRSTHDR(&mhdr));
			return fd;
		}

}

void main()
{
		int usfd,sfd,nusfd,nsfd,usfd2;
	    usfd=getusfd();
		sfd=getsfd();
		usfd2=ugetconnect();

	    printf("waiting for c-server.......\n");
	     nusfd=accept(usfd,NULL,NULL);
		if(nusfd<0)
		{
			perror("c-server-not-accepted\n");
			exit(-1);
		}
		else printf("c-server-accepted\n");
		int count=0;

		struct pollfd fds[2];
		fds[0].fd=nusfd;
		fds[0].events=POLLIN;
		fds[1].fd=sfd;
		fds[1].events=POLLIN;

		while(1)
		{
			int temp=poll(fds,2,5);
			if(temp>0)
			{
					 
					if(fds[0].revents&POLLIN)
					{
						printf("server-c has sent fd\n");
						if(count>=mx_client)
						{
							nsfd=recvfd(fds[0].fd);
							if(sendfd(usfd2,nsfd)<0)
							{
								perror("fd not sent\n");
								exit(-1);
							}
							else printf("recv-fd-sent\n");
						}
						else
						{
							nsfd=recvfd(fds[0].fd);
							count++;
							printf("seat allocated1\n");
						}	
					}
					if(fds[1].revents&POLLIN)
					{
						printf("client has reached\n");
						nsfd=accept(fds[1].fd,NULL,NULL);
						if(count>=mx_client)
						{
				
							if(sendfd(nusfd,nsfd)<0)
							{
								perror("fd not sent\n");
								exit(-1);
							}
							else printf("client-fd-sent\n");
						}
						else
						{
							count++;
							printf("seat allocated\n");
						}	
					}
			
			}
			
		}


}