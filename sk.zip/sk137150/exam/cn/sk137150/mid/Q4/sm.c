#include<stdio.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/time.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<signal.h>

int platform[]={1,1,1};
int pfpids[3];
int shmid;

void handler(int signum)
{
     	int *pfnp=shmat(shmid,NULL,0);
	platform[*pfnp]=1;
}

int main()
{
	//shared memory
	 shmid=shmget(12345,1024,0666|IPC_CREAT);
	 if(shmid<0)
	{
		perror("shm");
		exit(-1);
	}
	//signal
	signal(12,handler);
	//socket
	int sfdv=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	int sfdh=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	int sfdd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	//BIND
	struct sockaddr_in myaddr;
	myaddr.sin_family=AF_INET;
	myaddr.sin_addr.s_addr=htonl("127.0.0.1");
	myaddr.sin_port=htons(55555);
	socklen_t ll=sizeof(myaddr);
	bind(sfdv,(struct sockaddr*)&myaddr,ll);
	
	myaddr.sin_port=htons(55544);
	 ll=sizeof(myaddr);
	bind(sfdh,(struct sockaddr*)&myaddr,ll);

	myaddr.sin_port=htons(55588);
	 ll=sizeof(myaddr);
	bind(sfdd,(struct sockaddr*)&myaddr,ll);
	//listen
	listen(sfdv,4);
	listen(sfdt,4);
	listen(sfdd,4);
	//select
	int sfds[]={sfdv,sfdh,sfdd};
	fd_set readfds;
	int i,j,c,temp;
	struct timeval tv;
	tv.tv_sec=5;
	tv.tv_usec=0;
	char **str;
	int nsfd;
	while(1)
	{
		for(i=0;i<3;i++)
		{
			FD_SET(sfds[i],&readfds);
			if(sfds[i]>temp)
			temp=sfds[i];
		}
		int temp2=select(temp+1,&readfds,NULL,NULL,&tv);
		if(temp2!=0)
		{
			for(i=0;i<3;i++)
			{			
			  if(FD_ISSET(sfds[i],&readfds))
				{
				   for(j=0;j<3;j++)
					if(platform[j]==1)
						break;
					if(j<3)	
					{
					   	c=fork();
					    if(c==0)
					    {
						nsfd=accept(sfds[i],NULL,NULL);
						dup2(nsfd,1);
						dup2(nsfd,0);
						if(j==0)
						execv("p1",str);
						else if(j==1)
						execv("p2",str);
						else if("p3",str);
					     }
					     else
					     {
						platform[j]=0;
						pfpids[j]=c;
							
					     }	
					}
				}	
			}
		}
	}
	

}


