#include<stdio.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/time.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<signal.h>

int shmid;

int main()
{
	//shared memory
	 shmid=shmget(12345,1024,0666|IPC_CREAT);
	 if(shmid<0)
	{
		perror("shm");
		exit(-1);
	}
	char buff[100];

		read(0,buff,sizeof(buff));
		printf("platform p1 received train:%s\n",buff);
		 
		recv(0,buff,sizeof(buff),0);
		int *pp=shmat(shmid,NULL,0);
		*pp=0;
		kill(getppid(),12);
		return 0;
}


