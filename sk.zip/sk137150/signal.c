#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<signal.h>

void handler(int signum)
	{
		printf("\ni have handled signal no=%d",signum);
	}

int main()
{
	int c;
	pid_t pid=getpid();
	 c=fork();
	if(c>0)
	{
		
		
		printf("i am parent\n");
		signal(SIGINT,handler);//handler is registered to signal SIGINT
		wait(NULL);
	}
	else
	{
		printf(" i am child\n");
		kill(pid,SIGINT);
	}	

	return 0;	
}
