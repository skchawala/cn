#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<sys/signal.h>
#include<sys/poll.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<semaphore.h>
#include<time.h>
#include<sys/stat.h>

void handler(int signum)
{
	FILE *fp3,*fp5;
	char buff[100]="init";	
	int cnt;  
	fp3=popen("./aiop3","r");
	cnt=fread(buff,sizeof(buff),1,fp3);
	printf("total%d\n",cnt);
	if(cnt>=0)
	{
	  printf("allinone got data from p3:%s\n",buff);

			fp5=popen("./aiop5","w");
		 	 cnt=fwrite(buff,sizeof(buff),1,fp5);
        		if(cnt>=0)
        		 printf("allinone sent data to p5:%s\n",buff);
         }
	signal(signum,handler); 
}
int main()
{
	//create a file
	FILE* tt=fopen("file.txt","w");
		if(tt==NULL)
		{
			perror("file could not created");
			exit(-1);
		}
		fclose(tt);
	//for share memory if nead
	key_t key=1234;
	size_t size=1024;
	int fflag=0666|IPC_CREAT;
	 int shmid=shmget(key,size,fflag);
	if(shmid<0)
	{
		perror("shmid");
		exit(-1);
	}
	int *ptr=shmat(shmid,NULL,0);
	     *ptr=getpid();
		shmdt(ptr);
	printf("allinone pid:%d\n",getpid());	
 	//fifo
	char *str="ffifo";
	/*if(mkfifo(str,S_IWUSR | S_IRUSR |S_IRGRP | S_IROTH)<0)
	{
		perror("mkfifo");
		exit(-1);
	}*/
	//prepare polling
	struct pollfd fds;
	fds.fd=open("file.txt",O_RDWR);
	fds.events=POLLIN|POLLOUT;
	
	//popen
	 char *prc1="./aiop5";
	 char *proc2="./aiop3";
	 //signal
	  int signum=SIGTSTP;
	   int pid;            //from share memory;
		signal(signum,handler); 
	char buff[1024]="";
	int d=open(str,O_RDWR);
	 while(1)
	{   	
			printf("waiting\n");
	         	 if(d<0)
	            	{
			  perror("popen server\n");
			  exit(-1);
			}
		read(d,buff,sizeof(buff));
		printf("data read by server from fifo is:%s\n",buff);
		poll(&fds,1,-1);
		if(fds.events&&POLLIN)
		{
				if(read(fds.fd,buff,sizeof(buff))>0)
					{
						printf("data read by server(polling) is :%s\n",buff);
					}
		}
		sleep(5);
	}
	
}

