#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<sys/ipc.h>

int main()
{
	//fifo
	char buff[1024]="i am process p2";
	char *str="ffifo";
	 int fd=open(str,O_RDWR);
	char arr[]={'a','b','c','d'};
	int i=0;
	while(1)
	{
	 if(fd<0)
	 {
		perror("popen p2\n");
		exit(-1);
	 }
	 	write(fd,buff,sizeof(buff));
	 printf("data written by p2\n");
	buff[strlen(buff)%1024]=arr[i%4];
	 i++;
	 sleep(5);
	}
	return 0;
		
}
