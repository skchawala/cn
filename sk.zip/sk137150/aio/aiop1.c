#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<sys/signal.h>
#include<sys/poll.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<semaphore.h>
#include<time.h>

int main()
{
	char buff[100]="i am process 1";
	int fd=open("file.txt",O_RDWR|O_APPEND);
	if(fd<0)
	{
		perror("p1");
		exit(-1);
	}	
	int i=0;
	char arr[]={'a','b','c','d'};
	while(1)
	{
		buff[strlen(buff)%100]=arr[i%4];
		write(fd,buff,sizeof(buff));
		printf("process p1 is written data-times:%d\n",i);
		sleep(5);
		i++;
	}
	return 0;	
}
