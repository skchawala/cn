#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<sys/ipc.h>

int main()
{
	char buff[1024];
	read(0,buff,sizeof(buff));
	printf("process p5 has read:data=%s\n",buff);
	return 0;
	
}
