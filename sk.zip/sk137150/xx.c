#include<stdio.h>
#include<unistd.h>
#include<sys/shm.h>
#include<signal.h>
#include<stdlib.h>
#include<sys/ipc.h>
int flag=-1;
int shmid1,shmid2;
int cpid,ppid;
void handler(int signum)
{
	int *ptrx,*ptry;
	int x,y;
	//attach x
	 ptrx=shmat(shmid1,NULL,0666);//read-write both;
	//attach y
	 ptry=shmat(shmid2,NULL,0666);//read-write both;
	
	 if(flag==1)//p1
	 {
		//read from y;
		 	y=*ptry;
			x=y+1;
		//write to x
		*ptrx=x;
		printf("\np1:\nread=%d and write=%d\n",y,x);
		sleep(2);
		 kill(cpid,signum);               //send signal to p2/cpid
         }
	else //p2 
	{
		
		//read from x;
			x=*ptrx;
			if(x!=-1);
			y=x+1;
		//write to y	
		*ptry=y;
		printf("\np2:\nread=%d and write=%d\n",x,y);
		sleep(2);
		 kill(ppid,signum); 		//send signal to p1/ppid
	}
		

	signal(signum,handler);	 /* NOTE some versions of UNIX will reset signal to
                                  defaultafter each call. So for portability reset signal each time */
	
}
int main()
{
	//create shared memory x
	 key_t key=123456;
	 size_t size=1024;
	 int shmflg=0666|IPC_CREAT;//creating and read-write permission
	
	 shmid1=shmget(key,size,shmflg);

	if(shmid1==-1)
	{
		perror("shmid1\n");
		exit(1);
	}
	

	//create shared memory y
	  key=654321;
	 shmid2=shmget(key,size,shmflg);

	if(shmid2==-1)
	{
		perror("shmid2\n");
		exit(1);
	}
	//attach y
	int* pt=shmat(shmid2,NULL,0666);//read-write both;
	//initialize y
	*pt=1;
	//create second process
	int pid=getpid();
	 ppid=pid;
	 cpid=0;
	signal(SIGINT,handler);

	int c=fork();
	if(c==-1)
	{
		perror("fork\n");
		exit(1);
	}
	
	if(c==0)
	{
		 sleep(1);
		flag=0;
		sleep(2);
		kill(pid,SIGINT);
	}
	else
	{
		flag=1;
		sleep(2);
		kill(0,SIGINT);	
		wait(NULL);   //wait for child to finish
	}
	
			
	return 0;
}
