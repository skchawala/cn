#include<stdio.h>
#include<unistd.h>

int main()
{
	FILE* fd;
	int fd2;
	char str[100]="i am really good here .what are you doing honey";
	printf("\nthis is popencall main\n");
	fd=popen("./p2","w");
	fd2=fileno(fd);
	//int t=fwrite(str,1,sizeof(str),fd);
	//printf("t=%d",t);
	printf("\nenter in main\n");
	//scanf("%s",str);
	printf("after=%s",str);
	//fgets(str,sizeof(str),fd);
	  //printf("%s",str);
		//wait(NULL);
	//int t=fwrite(str,1,sizeof(str),fd);
	
	int t=write(fd2,str,sizeof(str));
       // pclose(fd);
//	for(; ;)
   // sleep(5);
	return 0;
}

