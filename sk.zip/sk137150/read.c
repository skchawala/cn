#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
int main()
{
	
	int i=0;
	char msg[100];
	read(0,msg,100);
	printf("%s",msg);

	//dup2(0,STDIN_FILENO);
	//scanf("%s",msg);
	//printf("%s",msg);

	return 0;
}

