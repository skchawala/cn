#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
typedef struct buffer
	{
		char* msg;
		int tag;
	} ds;
int main()
{
	
	int fd[2];
	pipe(fd);
	int c;
	//ds *buff,*buff2;
	char buff[100]="wow!amyourfather.hison what are you doing.do you want some food";
	char buff2[100];
	char *const argv[2];
	c=fork();
	if(c>0)
	{
		printf("this is parent.\n");
		//buff->msg="djkfghsdkjfghsdkjfhgsdkjhfk";
		
		//buff->tag=1;
		//close(fd[0]);
		printf("fd[1]=%d",fd[1]);
		while(1){
		write(fd[1],buff,strlen(buff));
		printf("written\n");
		}
		//read(fd[0],buff,sizeof(buff));
		//printf("%s",buff);
		printf("fd[1]=%d",fd[1]);
		wait(NULL);
		printf("end of the father\n");
	}
	else
	{
		printf("this is child\n");
		close(fd[1]);
		
		//if(dup2(fd[0],0)<0)
			//printf("no dup2s");
		//if(execv("readc",argv)<0)
			//printf("error");
		while(1){
		read(fd[0],buff2,5);
		printf("message is:%s \n",buff2);
		}
	}
	return 0;
}

