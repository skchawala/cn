#include<stdio.h>
#include<unistd.h>

int main()
{
	int fd[2];
	pipe(fd);
	char str[100]="sdfgskdfgskldfhgklsghfdlsglk";
	char str2[100];
	write(fd[1],str,sizeof(str));
	read(fd[0],str2,sizeof(str));
	printf("%s",str2);
	return 0;
}
