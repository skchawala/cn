#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include<stdio.h>
int main()
{
    int fd;
    char * myfifo = "myfifo";

    /* create the FIFO (named pipe) */
   // mkfifo(myfifo, 0666);

    /* write "Hi" to the FIFO */
    fd = open(myfifo, O_WRONLY);
	char buff[10];
	while(1){
	printf("type..\n");
	scanf("%s",buff);
    write(fd, buff, sizeof(buff));
	printf("written\n");
	//sleep(5);
	
	}
//for(;;);
    close(fd);

    /* remove the FIFO */
   // unlink(myfifo);

    return 0;
}


