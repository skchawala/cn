#include<stdio.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<unistd.h>
#include<sys/sem.h>
#include<sys/types.h>
#include<stdlib.h>
int main(int argc,char **argv)
{
	
	//semaphore 
	struct sembuf wait2,sig2;
	wait2.sem_num=0;
	wait2.sem_op=-1;
	wait2.sem_flg=SEM_UNDO;

	sig2.sem_num=0;
	sig2.sem_op=1;
	sig2.sem_flg=SEM_UNDO;

	key_t key=56789;
	int nsems=1;
	int semflg=0666|IPC_CREAT;

	int semid2=semget(key,nsems,semflg);
	if(semid2<0)
	{
		perror("semid\n");
		exit(-1);
	}
	semctl(semid2,0,SETVAL,1);
//-------------------------------
	
	char buff[100]="i am process p3";
	while(1)
	{

		semop(semid2,&wait2,1);
		write(1,buff,sizeof(buff));
		sleep(5);
	}


}
