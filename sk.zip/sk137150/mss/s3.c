#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
void main()
{
	
	
	char ff[100]="oops";
	int i,j;
	read(0,ff,sizeof(ff));
	char temp[100];
	strcpy(temp,ff);
	strcat(temp,"1");

	int fdr=open(temp,O_RDONLY);

	strcpy(temp,ff);
	strcat(temp,"2");

	int fdw=open(temp,O_WRONLY);
	
	strcpy(ff,"hello i am servive s3");
	write(fdw,ff,sizeof(ff));
	strcpy(ff,"i am service s3");
	while(1)
	{

		read(fdr,temp,sizeof(temp));
		printf("%s\n",temp);
		write(fdw,ff,sizeof(ff));
	}
	
	return ;
}
