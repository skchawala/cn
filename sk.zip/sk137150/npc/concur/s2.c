#include <sys/types.h>
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include<fcntl.h>
void main()
{

	
while(1)
{                      
                        printf("waiting to read\n");
			temp=read(0,buff,sizeof(buff));
			if(temp<=0)
			{
				exit(-1);
			}
			printf("received from:%s and amount:%d",buff,temp);

			write(1,"i am server",sizeof("i am server"));
}
		return ;
}
