  #include <sys/types.h>
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include<fcntl.h>
void main()
{

	int temp;
//step1-------------s------------------create socket

	int sfd;
	int family=AF_INET;
	int type=SOCK_STREAM;
	int protocol=IPPROTO_TCP;
	sfd=socket(family,type,protocol);
	if(sfd<0)
	{
		perror("socket\n");
		exit(-1);
	}
	printf("s is ok\n");
//step2---------------b----------bind socket to local port and ip
	struct sockaddr_in myaddr;
	memset(&myaddr,0,sizeof(myaddr));
	myaddr.sin_family=AF_INET;

	myaddr.sin_port=htons(8080);//convert to network byte order
	myaddr.sin_addr.s_addr=htonl(INADDR_ANY);//inet_addr("172.30.123.108");//htonl(INADDR_ANY);//IP address is wildcarded using INADDR_ANY
	socklen_t addrlen=sizeof(myaddr);
	temp=bind(sfd,(struct sockaddr *)&myaddr,addrlen);
	if(temp<0)
	{
		perror("bind\n");
		exit(-1);
	}
	printf("b is ok\n");
//step 3----------l--------------------------listen to connection on socket sfd
	int n=3;
	temp=listen(sfd,n);
	if(temp<0)
	{
		perror("listen\n");
		exit(-1);
	}
	printf("l is ok\n");

		
       // char *iip=inet_ntoa(clientaddr.sin_addr);
	//printf("ip=%s\n",iip);
	while(1)
	{
			//step4---------a---------------------accept 

		//struct sockaddr_in clientaddr;
		//socklen_t ss;
		int nsfd;
		printf("waiting for client in main server\n");
		nsfd=accept(sfd,(struct sockaddr *)NULL,NULL);
		printf("client visited\n");
		if(nsfd<0)
		{
		perror("accept\n");
		exit(-1);
		}
		printf("accepted\n");

		int c=fork();
		char *ttt[100];
	if(c==0)
	{
		         close(sfd);
			dup2(nsfd,0);
			dup2(nsfd,2);
			execv("s1",ttt);
	}
	else
	{
	  close(nsfd);	
	}
     }

  return ;
}
