  #include <sys/types.h>
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include<fcntl.h>
void main()
{

	int temp;
//step1-------------s------------------create socket

	int sfd;
	int family=AF_INET;
	int type=SOCK_STREAM;
	int protocol=IPPROTO_TCP;
	sfd=socket(family,type,protocol);
	if(sfd<0)
	{
		perror("socket\n");
		exit(-1);
	}
//STEP2--------------c---------------connect to remote host/server/other client over network;

	struct sockaddr_in servaddr;
	memset(&servaddr,0,sizeof(servaddr));

	socklen_t servlen;
	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(8080);
	servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");//;("172.30.123.108");//in network byte order
	servlen=sizeof(servaddr);
	temp=connect(sfd,(struct sockaddr *)&servaddr,servlen);
	if(temp<0)
	{
		perror("connect\n");
		exit(-1);
	}
	//read-write
	char buff[100];
	int flg=fcntl(sfd,F_GETFL); //CURRENT FLAG
	int i=1;
	char str[10];
	printf("type..\n");
			scanf("%s",buff);
	while(1)
	{
		//temp=recv(sfd,buff,sizeof(buff),flg);
			printf("type..\n");
			scanf("%s",buff);
			// temp=send(nsfd,buff,sizeof(buff),flg);
			temp=write(sfd,buff,sizeof(buff));
		printf("sent to server:%sand amount%d\n",buff,temp);
		read(sfd,buff,sizeof(buff));
		printf("got response from server:%s\n",buff);
	}
	

	
  return ;
}
