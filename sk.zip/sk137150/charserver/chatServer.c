#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/poll.h>
#include<sys/sem.h>
#include<sys/types.h>
#include<sys/signal.h>
#include<pthread.h>
#include<sys/shm.h>
#include<sys/time.h>

#define max_user 5

int num_cur_user=0;
int fds[max_user], fds2[max_user],pids[max_user];
int readfrom=-1;
int shmid,semid,semid2,msgid;

char buff[500]="hi";

struct sembuf wait2,sig2;
struct sembuf wait[2],sig[2];
struct pollfd 	pfd[max_user];

struct msgbuf
{
	long type;
	char msg[256];
	
};

void *readthread(void* args)
{
		int i,retv;
		while(1)
		{
			
	     		semop(semid,&wait[0],1);
			printf("\nreader.....\n");

			printf("server is waiting for any user to write\n");
			//
			
	  		retv=poll(pfd,num_cur_user,5);
			printf("retv=%d\n",retv);
		 if(retv>0)
	 	 {
			printf("\nselect  selected\n");	
			for(i=0;i<num_cur_user;i++)
			{	
				printf("check-read\n");
				if(pfd[i].revents&POLLIN)
				{
					printf("\ndata available to read from%d\n",i);
					read(pfd[i].fd,buff,sizeof(buff));
					readfrom=i;
					printf("read:%s\n",buff);
					break;
				}	
			}	
		 }

			semop(semid,&sig[1],1);
			sleep(1);	
	}	
}	
void *writethread(void* args)
{	
	int i;
	while(1)
	{        
		semop(semid,&wait[1],1);
		printf("\nwriter.....\n");
		
		if(readfrom!=-1)
		{
			printf("\ndata available to write\n");
	 		for(i=0;i<num_cur_user;i++)
			{
				printf("check-write\n");
				if(i!=readfrom)
				{
					printf("total:%d\n",num_cur_user);
					kill(pids[i],42);
					write(fds2[i],buff,sizeof(buff));
				}
			}
		printf("server has sent msg to all\n");	
		}
		else printf("\nno data availabel\n");
		        readfrom=-1;
		 semop(semid,&sig[0],1);
		 sleep(1);	
	 }		
}
void adduser(int signum)
{
	
	//read user info
	 struct msgbuf buff;
	int tp=msgrcv(msgid,&buff,500,1,0);
	if(tp<=0)
	{
		perror("adduser\n");
		exit(-1);
	}
	

	char *str=buff.msg;
	 int len=strlen(str);
		printf("%s and %d",str,len);
	char ff[256]="";
         char pp[256]="";
	int i,j;
	for( i=0;str[i]!='|'&&i<len;i++)
	{
		ff[i]=str[i];
	}
	i++;
	j=0;
	for(;i<len;i++)
	{
		pp[j++]=str[i];
	}
	int p_id=atoi(pp);
	printf("%s -server\n",ff);
		
	char *sf=shmat(shmid,NULL,0);
	
	if(num_cur_user>=max_user)
	{
		
		*sf='n';
		kill(p_id,SIGTSTP);
          printf("sent confirmation (n) to-- %s--user\n",ff); 
	}
	else{
		*sf='y';
 		pfd[num_cur_user].fd=open(ff,O_RDONLY);
		if(pfd[num_cur_user].fd<0)
		{
			perror("fds\n");
			
		}
		kill(p_id,SIGTSTP);
              printf("sent confirmation (y) to-- %s--user\n",ff); 
		 strcat(ff,"1");
		fds2[num_cur_user]=open(ff,O_WRONLY);
		if(fds2[num_cur_user]<0)
		{
			perror("fds2\n");
			
		}
		pids[num_cur_user]=p_id;
		 num_cur_user++;
		printf("user with process id %d and fifo %s added\n",p_id,ff);
	 }
	
	 
	signal(SIGTSTP,adduser);
	semop(semid2,&sig2,1); 
	
}

void main()
{
//------------------------------------------------------------------------------------
	//variables
	key_t key;
	size_t size=1024;
	int *tt,i,nsems, fflag=0666|IPC_CREAT,semflg,shmid2;
//------------------------------------------------------------------------------------
	for(i=0;i<max_user;i++)
		{
			pfd[i].fd=-1;
			pfd[i].events=POLLIN;
		}
//------------------------------------------------------------------------------------
//temp shared memory
	 key=445566;
	shmid=shmget(key,size,fflag);
	if(shmid<0)
	{
		perror("shmid");
		exit(-1);
	}
//---------------------------------------------------------------------------------------
	//msg-queue
	key=1234567;
	msgid=msgget(key,fflag);
	if(msgid<0)
	{
		perror("msgid");
		exit(-1);
	}
//---------------------------------------------------------------------------------------
	//only for server info
	  key=887755;
	  shmid2=shmget(key,size,fflag);
	if(shmid2<0)
	{
		perror("shmid2");
		exit(-1);
	}	
       tt=shmat(shmid2,NULL,0);
	*tt=getpid();
	if(tt==NULL)
	{
		perror("adduser\n");
		exit(-1);
	}
//--------------------------------------------------------------------------------------------
	//semaphore for msgqueue
	
	wait2.sem_num=0;
	wait2.sem_op=-1;
	wait2.sem_flg=SEM_UNDO;

	sig2.sem_num=0;
	sig2.sem_op=1;
	sig2.sem_flg=SEM_UNDO;

	 key=56789;
	 nsems=1;
	 semflg=0666|IPC_CREAT;

	semid2=semget(key,nsems,semflg);
	if(semid2<0)
	{
		perror("semid\n");
		exit(-1);
	}
	semctl(semid2,0,SETVAL,1);
//--------------------------------------------------------------------------------------------------
	//semaphore for threads
	wait[0].sem_num=0;
	wait[0].sem_op=-1;
	wait[0].sem_flg=SEM_UNDO;

	wait[1].sem_num=1;
	wait[1].sem_op=-1;
	wait[1].sem_flg=SEM_UNDO;

	sig[0].sem_num=0;
	sig[0].sem_op=1;
	sig[0].sem_flg=SEM_UNDO;

	sig[1].sem_num=1;
	sig[1].sem_op=1;
	sig[1].sem_flg=SEM_UNDO;
	
	 key=ftok("..",5);
	 nsems=2;
	 semid=semget(key,nsems,semflg);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);
	}
	semctl(semid,0,SETVAL,1);
	semctl(semid,1,SETVAL,0);
//------------------------------------------------------------------------------------
	//signal
	signal(SIGTSTP,adduser);
//-------------------------------------------------------------------------------------
	//creating theads;
	 pthread_t rd,wr;
	 pthread_create(&rd,NULL, readthread, NULL);
	 pthread_create(&wr,NULL, writethread, NULL);
		  pthread_join(rd, NULL);
		  pthread_join(wr, NULL);
		printf("end of server\n");
	return ;
}
