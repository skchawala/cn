#include<stdio.h>
#include<unistd.h>
#include<sys/shm.h>
#include<signal.h>
#include<stdlib.h>
#include<sys/ipc.h>

int shmid1,shmid2;
int cpid,ppid;
void handlerp(int);
void handlerc(int);


int main()
{
	//create shared memory x
	 key_t key=123456;
	 size_t size=1024;
	 int shmflg=0666|IPC_CREAT;//creating and read-write permission
	
	 shmid1=shmget(key,size,shmflg);

	if(shmid1==-1)
	{
		perror("shmid1\n");
		exit(1);
	}
	

	//create shared memory y
	  key=654321;
	 shmid2=shmget(key,size,shmflg);

	if(shmid2==-1)
	{
		perror("shmid2\n");
		exit(1);
	}
	
      //attach y
	int* pt=shmat(shmid2,NULL,0666);//read-write both;
	//initialize y
	*pt=1;
	//create second process
	int pid=getpid();
	 ppid=pid;//p1
	 cpid=0;  //p2

       signal(SIGTSTP,handlerp);

	int c=fork();
	
	if(c==-1)
	{
		perror("fork\n");
		exit(1);
	}
	
	if(c==0)
	{
		//signal(SIGTSTP,handlerc);
		while(1)
		{
			pause();	
		  
		}
	}
	else
	{
		// signal(SIGTSTP,handlerp);
		 kill(ppid,SIGTSTP);
		while(1) 
		{	
		   //printf("p1 is waiting\n");
			pause();
		}
		 wait(NULL);   //wait for child to finish
	}
	
			
	return 0;
}
void handlerp(int signum)
{
	int *ptrx,*ptry;
	int x,y;
	//attach x
	 ptrx=shmat(shmid1,NULL,0666);//read-write both;
	//attach y
	 ptry=shmat(shmid2,NULL,0666);//read-write both;
	
        signal(signum,handlerc);	 /* NOTE some versions of UNIX will reset signal to
                                  //defaultafter each call. So for portability reset signal each time */
	 
		//read from y;
		 	y=*ptry;
			x=y+1;
		//write to x
		*ptrx=x;
		printf("\np1:\nread=%d and write=%d\n",y,x);
		 sleep(5);
		 kill(cpid,signum);               //send signal to p2/cpid

}
void handlerc(int signum)
{
	int *ptrx,*ptry;
	int x,y;
	//attach x
	 ptrx=shmat(shmid1,NULL,0666);//read-write both;
	//attach y
	 ptry=shmat(shmid2,NULL,0666);//read-write both;
	
       signal(signum,handlerp);	 /* NOTE some versions of UNIX will reset signal to
                                  //defaultafter each call. So for portability reset signal each time */
		
		//read from x;
			x=*ptrx;
			if(x!=-1);
			y=x+1;
		//write to y	
		*ptry=y;
		printf("\np2:\nread=%d and write=%d\n",x,y);
		 sleep(5);
		 kill(ppid,signum); 		//send signal to p1/ppid
}
