#include<stdio.h>
#include<unistd.h>
#include<sys/signal.h>
#include<sys/time.h>
#include<sys/select.h>
#include<sys/ipc.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
void main()
{

	int fds[5];
	char str[][10]={"first","second","third","fourth","fifth"};
	int i,n=5;
	int flg=0666|IPC_CREAT;
	/*for(i=0;i<n;i++)
	 if(mkfifo(str[i],0666|IPC_CREAT)<0)
		{
			perror("fifo\n");
			exit(-1);
		}
		*/
	 fd_set readfds,writefds,exceptfds;

	struct timeval timeout;

	timeout.tv_sec=10;
	timeout.tv_usec=10000;
	int nfds=-1;
	
	 for(i=0;i<n;i++)
	  {
		fds[i]=open(str[i],O_RDWR);
		if(fds[i]<0)
		{
			perror("fds\n");
					
			exit(-1);
		}
		if(nfds<fds[i])
			nfds=fds[i];
	  }

    while(1)
	{
		//clearing sets
		FD_ZERO(&readfds);
		FD_ZERO(&writefds);
		FD_ZERO(&exceptfds);
		//adding fds to sets
		FD_SET(fds[0],&readfds);
		FD_SET(fds[1],&readfds);
		FD_SET(fds[2],&writefds);
		FD_SET(fds[3],&writefds);
		FD_SET(fds[4],&exceptfds);

		//selecting
		printf("waiting....\n");
		int tag=select(nfds+1,&readfds,&writefds,&exceptfds,&timeout);
		//checking
		char buff[100]="oops";
		int t;
	if(tag!=-1)
	{
		for(i=0;i<n;i++)
		{
			if(FD_ISSET(fds[i],&readfds))
			{
				t=read(fds[i],buff,sizeof(buff));
				printf("read from fifo-%s data is:%s and total:%d\n",str[i],buff,t);
			}
			 if(FD_ISSET(fds[i],&writefds))
			{
				
				t=write(fds[i],buff,sizeof(buff));
					if(t!=0)
				printf("writen to fifo-%s data is:%sand total:%d\n",str[i],buff,t);
			}
			 if(FD_ISSET(fds[i],&exceptfds))
			{
			   printf("exceptional%s\n",str[i]);
			   perror("");
			}
		
		}
	}
	else perror("select()\n");
	sleep(4);
    }
 
}
