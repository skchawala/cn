#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/select.h>
#include<signal.h>
#include<sys/time.h>

#define max_proc 5


struct sembuf wait,sig;
struct timeval tv;
int semid;
int ffd;
int fds[max_proc];
int cur=0;

char fifoarray[5][5];
fd_set readfds;

void allot(int signum)
{
	int i,j,len;
		
		char str[100]="";
		char temp1[100]="";
		char temp2[100]="";
		char st1[200]="./";
		
		tv.tv_sec=5;
		tv.tv_usec=0;

		printf("waiting for input......\n");
		read(ffd,str,sizeof(str));

		printf("allocating.....\n");

		// char *st=str;
		len=strlen(str);
		for(i=0;str[i]!='|'&&i<len;i++)//service name
			temp1[i]=str[i];
		i++;
		j=0;
		for(;i<len;i++)	//fifo name
		temp2[j++]=str[i];
		
		printf("fifo:%s\n",temp2);
		strcat(st1,temp1);
		printf("service:%s\n",st1);

		FILE* fp=popen(st1,"w");
		
		if(fp==NULL)
		{
			perror("there is no such service\n");				
		}
		
		int fd2=fileno(fp);
		  strcat(temp2,"|");
		  strcat(temp2,fifoarray[cur]);
			
		   i=write(fd2,temp2,sizeof(temp2));
			if(i<=0)
			{
			  perror("could not allocated\n");
				
			}
			else printf("allocated\n");
		 fds[cur]=open(fifoarray[cur],O_RDONLY);
		cur++;
////------------------------------------
                 int pid=getpid();
		char pid2[100];
		sprintf(pid2,"%d",pid);
		write(ffd,pid2,sizeof(pid2));		
		semop(semid,&sig,1);
		signal(SIGTSTP,allot);
}
void main()
{
	//variable
	size_t size=1024;
	int flag=0666|IPC_CREAT;
	key_t key=556677;
	int i,j;

//-----------------------------------------------
	//mss1,mss2,mss3,mss4,mss5

	/*if(mkfifo("mss",flag)<0)
	{
		perror("mss-fifo\n");
		exit(-1);
	}*/
	   	//printf("waiting2......\n");
//------------------------------------------------------
		char xx[100];
		char yy[5];
	 for(i=0;i<max_proc;i++)
	   {
		strcpy(xx,"mss");
		sprintf(yy,"%d",i+1);
		strcat(xx,yy);
		strcpy(fifoarray[i],xx);
 	   }
/*for(i=0;i<5;i++)
	if(mkfifo(fifoarray[i],flag)<0)
	{
		perror("mss-fifo\n");
		exit(-1);
	}*/
//
	//sem
	semid=semget(key,1,flag);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);	
	}
	wait.sem_num=0;
	wait.sem_op=-1;
	wait.sem_flg=SEM_UNDO;
	sig.sem_num=0;
	sig.sem_op=1;
	sig.sem_flg=SEM_UNDO;
	
	semctl(semid,0,SETVAL,1);
//---------------------------------------------------------
	ffd=open("mss",O_RDWR);	
	  int pid=getpid();
		char pid2[100];
		sprintf(pid2,"%d",pid);
		write(ffd,pid2,sizeof(pid2));	

	signal(SIGTSTP,allot);
	char log2[100];
	printf("waiting.....\n");
	 while(1)
		{
			
			FD_ZERO(&readfds);
			int rev=-1;
			for(i=0;i<cur;i++)
			{
				FD_SET(fds[i],&readfds);
				if(fds[i]>rev)
				rev=fds[i];
			}
		        select(rev+1,&readfds,NULL,NULL,&tv);
			for(i=0;i<cur;i++)
			{
				if(FD_ISSET(fds[i],&readfds))
				{
					strcpy(log2,"oops");
					 read(fds[i],log2,sizeof(log2));
		                          printf("server:%s\n",log2);
					  printf("waiting.....\n");
				}
			}
		
		}
	return ;
}
