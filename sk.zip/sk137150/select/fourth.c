#include<stdio.h>
#include<unistd.h>
#include<sys/signal.h>
#include<sys/time.h>
#include<sys/select.h>
#include<sys/ipc.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>

void main()
{

	char buff[100]="fourth";
	
		
	int fd=open("fourth",O_RDONLY);
		while(1)
		{
			read(fd,buff,sizeof(buff));
			printf("read:%s",buff);
		}
}
