#include<stdio.h>
#include<unistd.h>
#include<sys/signal.h>
#include<sys/time.h>
#include<sys/select.h>
#include<sys/ipc.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>

void main()
{

	char buff[100]="fifth";
	
		
	int fd=open("fifth",O_RDWR);
		while(1)
		{
			write(fd,buff,sizeof(buff));
			printf("writen:%s",buff);
			sleep(5);
		}
}
