#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/ipc.h>
#include<string.h>
int main()
{
	char buff[100]="";
	//scanf("%s",buff);
	read(0,buff,sizeof(buff));
	int ss=strlen(buff);
	buff[ss]='3';
	write(1,buff,sizeof(buff));
	 int  fd2=open("myfifo",0666);
	  write(fd2,buff,sizeof(buff));
	return 0;
	
}
