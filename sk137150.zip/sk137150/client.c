#include<stdio.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
int main()
{
	int fd;
	//char *path="/home/satish/sk137150/namedpipe";
	char str[50];
		if((fd=open("myfifo",O_RDONLY|O_NONBLOCK))!=-1)
			{
				read(fd,str,sizeof(str));
				printf("%s",str);
				close(fd);
			}
		     else 
			{
				printf("cant open in client");
			}
           
	return 0;
}
