#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/ipc.h>
#include<string.h>
int main(int argc,char** argv)
{

	int fd,i=1;
	FILE* fp;
	int fd2;
	char str[100]="i am khiladi=";
	 fd2=open("myfifo",0666);
	  write(fd2,str,sizeof(str));
	while(i<argc)
	{
		char st[3]="./";

		strcat(st,argv[i]);

		fp=popen(st,"w");
		fd=fileno(fp);

		read(fd2,str,sizeof(str));

		//fflush(fdopen(STDOUT_FILENO,"w"));
		fwrite(str,1,sizeof(str),fp);
		//write(fd,str,50);

		i++;
		printf("\n");
		pclose(fp);
		close(fd);
	}
	return 0;
}
