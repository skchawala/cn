#include<stdio.h>
#include<unistd.h>
#include<sys/poll.h>
#include<sys/ipc.h>
#include <fcntl.h>

int main()
{
	
	struct pollfd fds[3];

	fds[0].fd=STDOUT_FILENO;
	fds[0].events=POLLOUT|POLLIN;
	int i=0;
	char st[50];
	while(i<10)
	{	poll(fds,3,-1);
		if(fds[0].revents&POLLIN)
		{
			printf("yes\n");
			read(fds[0].fd,st,sizeof(st));
			//scanf("%s",st);
			printf("%s",st);
		}
		else printf("no\n");
	i++;
	}
	/*
	fds[2].fd=open("file1.txt",O_RDWR);
	fds[2].events=POLLIN|POLLOUT;
	fds[1].fd=fds[2].fd;
	fds[1].events=POLLOUT;
	
	char st[50];
	int i=0,j;
	while(i<5)
	{
		poll(fds,3,-1);
		
		for(j=0;j<3;j++)
		  {
			if(fds[j].revents&POLLIN)
			{
				printf("device %d is ready to be read\n",j);
				read(fds[j].fd,st,sizeof(st));
					fds[j].events=0;
			}
			else if(fds[j].revents&POLLOUT)
			{
				printf("device %d is ready to be written\n",j);
				write(fds[j].fd,"hi",sizeof("hi"));
				fds[j].events=0;
				
			}
			else if(fds[j].revents&POLLERR)
			printf("device %d GIVES ERROR:\n",j);
			else if(fds[j].revents&POLLHUP)
			printf("device %d is hanged up\n",j);
			//else if(fds[j].revents&POLLVAL)
			//printf("device %d :invalid request\n",j);
		   }
		sleep(1);
		i++;
	}*/

	return 0;
}
