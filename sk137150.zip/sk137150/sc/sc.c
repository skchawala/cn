#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/signal.h>
#include<sys/shm.h>
int semid;
struct sembuf wait,sig;
int ffd;
#define tot_serv 2

int avail=tot_serv;

void status(int signum)
{

	avail++;
	signal(42,status);
}
void allot(int signum)
{	
	        if(avail<=0)
		{
		   while(avail<=0)
			{
				sleep(1);
			}	
		}
		char str[100]="";
		char st1[200]="./s";

		printf("waiting......\n");
		read(ffd,str,sizeof(str));

		printf("allocating.....\n");

		printf("fifo:%s\n",str);

		FILE* fp=popen(st1,"w");
		
		if(fp==NULL)
		{
			perror("there is no such service\n");				
		}
		int fd=fileno(fp);
		 int  i=write(fd,str,sizeof(str));
			if(i<=0)
			{
			  perror("could not allocated\n");
				
			}
			else
			{
				 printf("allocated\n");
					avail--;
			}	
		
		semop(semid,&sig,1);
		signal(SIGTSTP,allot);
		fclose(fp);	
	printf("\nwaiting2......\n");
}
void main()
{
	//variable
	size_t size=1024;
	int flag=0666|IPC_CREAT;
	key_t key;
//-----------------------------------------------
	//fifo
	/*if(mkfifo("sc",flag)<0)
	{
		perror("sc-fifo\n");
		exit(-1);
	}*/
//------------------------------------------------------
//only for server info
	  key=887755;
	int  shmid2=shmget(key,size,flag);
	if(shmid2<0)
	{
		perror("shmid2");
		exit(-1);
	}	
     int*  tt=shmat(shmid2,NULL,0);
	*tt=getpid();
	printf("pid%d\n",*tt);
	if(tt==NULL)
	{
		perror("sc---\n");
		exit(-1);
	}
//---------------------------------------
	//sem for famous fifo
	 key=556677;
	semid=semget(key,1,flag);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);	
	}
//-----------------------------------------------
	wait.sem_num=0;
	wait.sem_op=-1;
	wait.sem_flg=SEM_UNDO;
	sig.sem_num=0;
	sig.sem_op=1;
	sig.sem_flg=SEM_UNDO;
	
	semctl(semid,0,SETVAL,1);

	signal(SIGTSTP,allot);
	signal(42,status);
//---------------------------------------------------------
	ffd=open("sc",O_RDWR);
	printf("\nwaiting1....\n");
	while(1)
	{
		sleep(2);
	}
	 
	return ;
}
