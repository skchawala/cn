#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/signal.h>
#include<sys/shm.h>

int s_pid;

void terminate(int signum)
{
	kill(s_pid,42);
	exit(-1);	
}
void main()
{

	char ff[100]="cust2";
	int i,j;
	char serv[100];
	/*if(mkfifo("cust21",0666|IPC_CREAT)<0||mkfifo("cust22",0666|IPC_CREAT)<0)
	{
		perror("cust1\n");
		exit(-1);	
	}*/
//---------------------------------------------------------------
	//variable
	size_t size=1024;
	int flag=0666|IPC_CREAT;
	key_t key=556677;;
	struct sembuf wait,sig;

	//sem
	int semid=semget(key,1,flag);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);	
	}

	wait.sem_num=0;
	wait.sem_op=-1;
	wait.sem_flg=SEM_UNDO;
	sig.sem_num=0;
	sig.sem_op=1;

	sig.sem_flg=SEM_UNDO;
//---------------------------------
	signal(SIGTERM,terminate);

//get server info
	 key=887755;
	int shmid2=shmget(key,size,flag);
	if(shmid2<0)
	{
		perror("shmid2");
		exit(-1);
	}
    	int* tt=shmat(shmid2,NULL,0);
	s_pid=*tt;
     printf("pid%d\n",s_pid);
//------------------------------------
         printf("wait for the server response.....");

	 semop(semid,&wait,1);

	int server=open("sc",O_WRONLY);
//---------------------------------------------
	  kill(s_pid,SIGTSTP);
	  write(server,ff,sizeof(ff));
//------------------------------------------------------------	
	 int fdw=open("cust21",O_WRONLY);
	 int fdr=open("cust22",O_RDONLY);
//----------------------------------------------------------
	while(1)
	{	
	
	 write(fdw,"i want service",sizeof("i want service"));
	 read(fdr,ff,sizeof(ff));
	  printf("GOT:%s\n",ff);
	  sleep(2);

	}
//-------------------------------------------------------------
	return ;
}
