#include<stdio.h>
#include<unistd.h>
#include<sys/signal.h>
#include<sys/time.h>
#include<sys/select.h>
#include<sys/ipc.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
void main()
{

	char buff[100]="second";
	
		
	int fd=open("second",O_WRONLY);
		while(1)
		{
			printf("type..\n");
			read(0,buff,sizeof(buff));
			write(fd,buff,sizeof(buff));
			printf("writen%s",buff);
		}
}
