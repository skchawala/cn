#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/poll.h>
#include<signal.h>

void main()
{
	int i;

//-----------------------------------------------
	//mss1,mss2,mss3,mss4,mss5

	if(mkfifo("mss",0666|IPC_CREAT)<0)
	{
		perror("mss-fifo\n");
		exit(-1);
	}
	char fifoarray[5][5];
	char xx[100];
	char yy[5];
	 for(i=0;i<5;i++)
	   {
		strcpy(xx,"mss");
		sprintf(yy,"%d",i+1);
		strcat(xx,yy);
		strcpy(fifoarray[i],xx);
 	   }
   for(i=0;i<5;i++)
	if(mkfifo(fifoarray[i],0666|IPC_CREAT)<0)
	{
		perror("mss-fifo\n");
		exit(-1);
	}
if(mkfifo("cust11",0666|IPC_CREAT)<0||mkfifo("cust12",0666|IPC_CREAT)<0)
	{
		perror("cust1\n");
		exit(-1);	
	}
if(mkfifo("cust21",0666|IPC_CREAT)<0||mkfifo("cust22",0666|IPC_CREAT)<0)
	{
		perror("cust2\n");
		exit(-1);	
	}
if(mkfifo("cust31",0666|IPC_CREAT)<0||mkfifo("cust32",0666|IPC_CREAT)<0)
	{
		perror("cust3\n");
		exit(-1);	
	}
//
return ;
}
