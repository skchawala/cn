#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
void main()
{
	
	
	char ff[100]="oops";
	char temp[100]="";
	char temp2[100]="";
	int i,j;
	read(0,ff,sizeof(ff));
	int len=strlen(ff);
	for(i=0;ff[i]!='|'&&i<len;i++)
		temp[i]=ff[i];
	i++;
	j=0;
	for(;i<len;i++)
	temp2[j++]=ff[i];

	int serfd=open(temp2,O_WRONLY);
	strcpy(ff,temp);
	strcat(temp,"1");

	int fdr=open(temp,O_RDONLY);

	strcpy(temp,ff);
	strcat(temp,"2");

	int fdw=open(temp,O_WRONLY);//to write to the client
	
	strcpy(ff,"hello i am servive s1");
	write(fdw,ff,sizeof(ff));	//to read from client
	strcpy(ff,"i am service s1");
	
	while(1)
	{

		read(fdr,temp,sizeof(temp));
		write(serfd,temp,sizeof(temp));
		write(fdw,ff,sizeof(ff));
	}
	
	return ;
}
