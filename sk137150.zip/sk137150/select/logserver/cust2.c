#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<signal.h>
void main()
{

	char ff[100]="|cust2";
	int i,j;
	char serv[100];
	/*if(mkfifo("cust21",0666|IPC_CREAT)<0||mkfifo("cust22",0666|IPC_CREAT)<0)
	{
		perror("cust2\n");
		exit(-1);	
	}*/
//---------------------------------------------------------------
	//variable
	size_t size=1024;
	int flag=0666|IPC_CREAT;
	key_t key=556677;;
	struct sembuf wait,sig;
	//sem
	int semid=semget(key,1,flag);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);	
	}
	wait.sem_num=0;
	wait.sem_op=-1;
	wait.sem_flg=SEM_UNDO;
	sig.sem_num=0;
	sig.sem_op=1;
	sig.sem_flg=SEM_UNDO;

	semop(semid,&wait,1);
	 int server=open("mss",O_RDWR);
		if(server<0)
		{
			perror("sever\n");
			exit(-1);
		}
//---------------------------------------------
  		int pid;
		char pid2[100]="hi";
		read(server,pid2,sizeof(pid2));
		pid=atoi(pid2);
//------------------------------------------------
	 printf("enter which service your want\n");
	 read(0,serv,sizeof(serv));

		strcat(serv,ff);
	 write(server,serv,sizeof(serv));
	kill(pid,SIGTSTP);
//------------------------------------------------------------	
	 int fdw=open("cust21",O_WRONLY);
	 int fdr=open("cust22",O_RDONLY);
//----------------------------------------------------------
		
	while(1)
	{	
		ff[0]='$';
	 write(fdw,"i want service",sizeof("i want service"));
	 read(fdr,ff,sizeof(ff));
	  printf("GOT:%s\n",ff);
	  sleep(2);
	}
//-------------------------------------------------------------
	return ;
}
