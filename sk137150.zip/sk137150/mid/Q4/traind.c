#include<stdio.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/time.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<signal.h>

int main()
{
	int sfd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	struct sockaddr_in smaddr;
	smaddr.sin_family=AF_INET;
	smaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	smaddr.sin_port=htons(55588);
	int temp=connect(sfd,(struct sockaddr*)&smaddr,sizeof(smaddr));
	if(temp<0)
	{
		perror("connect");
		exit(-1);
	}
	char buff[100]="i am train from delhi";
	write(sfd,buff,sizeof(buff));
	sleep(5);
	close(sfd);
	return 0;
}


