#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/poll.h>
#include<sys/sem.h>
#include<sys/types.h>
#include<sys/signal.h>
#include<pthread.h>
#include<sys/shm.h>

int shmid,msgid;

int ffd=-1,ffd2=-1;

struct sembuf wait2,sig2;
int semid;
char buffer[500]="oops";

struct msgbuf
{
	long type;
	char msg[256];
	
};

void responseFromServer(int signum)
{
	ffd2=open("fuser31",O_RDONLY);
	if(ffd2<=0)
	{
		perror("ffd2\n");
		exit(-1);
	}
	 printf("got server response\n");
	//read server info
	char *sf=shmat(shmid,NULL,0);
	if(sf==NULL)
	{
		perror("user3-response\n");
		exit(-1);
	}
	if(*sf=='y')
	{
		printf("user 3 got response:%s\n",sf);
	}
	else 
	{
		printf("sorry could not add\ntry again\n");
		exit(-1);
	}
	semop(semid,&sig2,1);
	printf("ffd2=%d\n",ffd2);
	
}

void readdata(int signum)
{
	
	 int t=read(ffd2,buffer,sizeof(buffer));
	   printf("recieve msg:%s\n",buffer);	
	   signal(42,readdata);
}
void main()
{
	 signal(SIGTSTP,responseFromServer);
	 signal(42,readdata);
	//variable
	key_t key;
	size_t  size=1024;
	int  fflag=0666|IPC_CREAT,temp,nsems,semflg,shmid2,*tt,s_pid;
//------------------------------------------------------------------------------------------
//temp shared memory
	 key=445566;
	shmid=shmget(key,size,fflag);
	if(shmid<0)
	{
		perror("shmid");
		exit(-1);
	}
//------------------------------------------------------------------------------------------	
	
	//fifo
	/* temp=mkfifo("user31",0666|IPC_CREAT);
	if(temp<0)
	{
		perror("user3\n");
		exit(-1);
	}*/
//-------------------------------------------------------------------------------------------
	//semaphore for msgqueue
	wait2.sem_num=0;
	wait2.sem_op=-1;
	wait2.sem_flg=SEM_UNDO;
	sig2.sem_num=0;
	sig2.sem_op=1;
	sig2.sem_flg=SEM_UNDO;
	 key=56789;
	 nsems=1;
	 semflg=0666|IPC_CREAT;

	semid=semget(key,nsems,semflg);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);
	}
//-----------------------------------------------------------------------------------
	//get server info
	 key=887755;
	shmid2=shmget(key,size,fflag);
	if(shmid2<0)
	{
		perror("shmid2");
		exit(-1);
	}
    	 tt=shmat(shmid2,NULL,0);
	 s_pid=*tt;
//-----------------------------------------------------------------------------------

	//give info to server
	//msg-queue
	  key=1234567;
	  msgid=msgget(key,fflag);
	if(msgid<0)
	{
		perror("msgid");
		exit(-1);
	}
	
	 struct msgbuf buff;
		int t1=getpid();
		char str[300]="";
		  strcat(str,"fuser3|");
		  char str2[50];	
		    sprintf(str2,"%d",t1);//int to string
		   strcat(str,str2);

		buff.type=1;
		strcpy(buff.msg,str);
			printf("msg:%s\n",buff.msg);
		semop(semid,&wait2,1);
		int ii=msgsnd(msgid,&buff,sizeof(buff));
		printf("ii=%d",ii);
		if(ii<0)
		{
			perror("msgrcv");
			exit(-1);
		}
	      else
	 	{
			// join the server
			 kill(s_pid,SIGTSTP);//request for joining
			 printf("user 3 has sent request to server with id:%d\n",getpid());
			 printf("waiting for the server response......\n");
			 ffd=open("fuser3",O_WRONLY);
				 printf("ffd=%d\n",ffd);
				if(ffd<=0)
				{
				 perror("ffd\n");
				 exit(-1);
				}
			
		}
		while(1)
	    {
		printf("\ntype---\n");
		read(0,buffer,sizeof(buffer));
		write(ffd,buffer,sizeof(buffer));
		printf("written to fd=%d\n",ffd);
	  }
//-----------------------------------------------------------------------------------
		return ;
		
}
