#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<sys/signal.h>
#include<sys/ipc.h>
#include<sys/shm.h>
int main()
{
	key_t key=1234;
	size_t size=1024;
	int fflag=0666|IPC_CREAT;
	 int shmid=shmget(key,size,fflag);
	if(shmid<0)
	{
		perror("shmid");
		exit(-1);
	}
	int *ptr=shmat(shmid,NULL,0);
	    int pid=*ptr;
	printf("process p4 has got pid:%d\n",pid);
		shmdt(ptr);
	while(1)
	{
		printf("process 4 has sent signal\n");
		kill(pid,SIGTSTP);		
		sleep(6);
	}
	return 0;
}
