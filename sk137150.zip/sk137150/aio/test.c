#include <stdio.h>
#include <string.h>

int main()
{
   FILE *fp;
   char c[] = "this is tutorialspoint";
   char buffer[100];

   /* Open file for both reading and writing */
   fp = fopen("file.txt", "r");

   /* Write data to the file */
 //  fwrite(c, strlen(c) + 1, 1, fp);

   /* Seek to the beginning of the file */
  // fseek(fp, SEEK_SET, 0);

   /* Read and display data */
   int tt=fread(buffer, strlen(c),1,fp);
   printf("%d\n", tt);
   fclose(fp);
   
   return(0);
}
