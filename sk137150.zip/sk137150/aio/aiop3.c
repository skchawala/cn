#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<sys/signal.h>
#include<sys/poll.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<semaphore.h>
#include<time.h>

int main()
{
	char buff[1024]="this is process 3";
	write(1,buff,sizeof(buff));

	return 0;
}
