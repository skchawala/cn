#include<stdio.h>
#include<unistd.h>

int main()
{
	char buff[100];
	//printf("this is p2.");
	//sleep(1);
	//int t2=fread(str,1,sizeof(str),STDIN_FILENO);
while(1){
	int i=read(0,buff,sizeof(buff));;
	//printf("\nt2=%d \nand str=%s\n",t2,str);
	printf("\ni=%d and str=%s\n",i,buff);
	//Sprintf("this is p2.");
	//printf("\nfinishy in p2\n");
	//close(1);
}
	return 0;
	
}

