#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
int semid;
struct sembuf wait,sig;
int ffd;

void allot()
{
	int i,j,len;	
	ffd=open("mss",O_RDWR);
	while(1)
	{
		
		char str[100]="";
		char temp1[100]="";
		char temp2[100]="";
		char st1[200]="./";

		printf("waiting......\n");
		read(ffd,str,sizeof(str));

		printf("allocating.....\n");

		// char *st=str;
		len=strlen(str);
		for(i=0;str[i]!='|'&&i<len;i++)//service name
			temp1[i]=str[i];
		i++;
		j=0;
		for(;i<len;i++)	//fifo name
		temp2[j++]=str[i];
		
		printf("fifo:%s\n",temp2);
		strcat(st1,temp1);
		printf("service:%s\n",st1);

		FILE* fp=popen(st1,"w");
		
		if(fp==NULL)
		{
			perror("there is no such service\n");				
		}
		int fd=fileno(fp);
		   i=write(fd,temp2,sizeof(temp2));
			printf("i=%d\n",i);
			if(i<=0)
			{
			  perror("could not allocated\n");
				
			}
			else printf("allocated\n");		
		semop(semid,&sig,1);
printf("ddd");	
		fclose(fp);
	printf("xyz")	;		
	}
}
void main()
{
	//variable
	size_t size=1024;
	int flag=0666|IPC_CREAT;
	key_t key=556677;
//-----------------------------------------------
	//fifo
	/*if(mkfifo("mss",flag)<0)
	{
		perror("mss-fifo\n");
		exit(-1);
	}*/
//------------------------------------------------------
	//sem for famous fifo
	semid=semget(key,1,flag);
	if(semid<0)
	{
		perror("semid\n");
		exit(-1);	
	}
	wait.sem_num=0;
	wait.sem_op=-1;
	wait.sem_flg=SEM_UNDO;
	sig.sem_num=0;
	sig.sem_op=1;
	sig.sem_flg=SEM_UNDO;
	
	semctl(semid,0,SETVAL,1);
//---------------------------------------------------------
	allot();
	 
	return ;
}
