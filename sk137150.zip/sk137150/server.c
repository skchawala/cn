#include<stdio.h>
#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
int main()
{

	int flag= S_IRWXU | S_IRWXG | S_IRWXO;
	int fd;
	char str[50]="hello sir";
	printf("\nsp1gdtgdgds\n");
	//fd=mkfifo("myfifo",flag);
	//printf("\nfd=%d\n",fd);
	//if(fd>=0)
         // {
		printf("\nffp2fgdff\n");

		fd=open("myfifo",O_WRONLY|O_NONBLOCK);

		printf("\nfd=%d\n",fd);

		if(fd!=-1)
			{
				printf("\np3\n");
				write(fd,str,sizeof(str));
				printf("\nwritten\n");
				close(fd);
			}
		else printf("\nerror:open server\n");
         //}
	//else printf("\nerror:mkfifo:%d\n",fd);

	return 0;
}
