#include <sys/types.h>
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <unistd.h>
  #include<fcntl.h>
void main()
{

char buff[100];
int temp;	
while(1)
{                      
                 
			temp=read(0,buff,sizeof(buff));
			if(temp<=0)
			{
			    perror("temp in s1\n");
			}
			write(1,"i am server s1",sizeof("i am server s1"));
}
		return ;
}
