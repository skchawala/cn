#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<sys/poll.h>
#include<sys/sem.h>
#include<sys/types.h>
#include<signal.h>
#include<pthread.h>
#include<sys/shm.h>
void main()
{
	char *str="hello|try";
	char st[100]=strsep(str,"|");
	char st2=strsep(str,"|");
	printf("%s %s %s",str,st,st2);
}
