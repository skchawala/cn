#include<stdio.h>
#include<fcntl.h>
#include<sys/ipc.h>
#include<unistd.h>
#include<sys/sem.h>
int main(int argc,char **argv)
{

	//semaphore 
	struct sembuf wait,sig2;
	wait2.sem_num=0;
	wait2.sem_op=-1;
	wait2.sem_flg=SEM_UNDO;

	sig2.sem_num=0;
	sig2.sem_op=1;
	sig2.sem_flg=SEM_UNDO;

	key_t key=56789;
	int nsems=1;
	int semflg=0666|IPC_CREAT;

	int semid2=semget(key,nsems,semflg);
	if(semid2<0)
	{
		perror("semid\n");
		exit(-1);
	}
//-------------------------------
	
	char buff[10]="i am process px";
	while(1)
	{

		semop(semid2,&wait,1);
		write(fd6,buff,sizeof(buff));
		sleep(5);
	}


}
