#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<signal.h>

int main()
{
	printf("i am sending signal");
	kill(
}
