#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(void)
{
		printf("\nbefore fflush\n");
   
        	int c=fflush(NULL);
		printf("\nafter fflush:%d\n",c);
   return 0;
}
