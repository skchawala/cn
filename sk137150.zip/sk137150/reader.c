#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAX_BUF 1024

int main()
{
    int fd;
    char * myfifo = "myfifo";
    char buf[MAX_BUF]="w";

    /* open, read, and display the message from the FIFO */
    fd = open(myfifo, O_RDONLY);
     printf("fff");
	while(1){
    read(fd, buf, 5);
    printf("Received: %s\n", buf);
	}

for(; ;);
    close(fd);

    return 0;
}
