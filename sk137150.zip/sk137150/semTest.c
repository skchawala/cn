#include<stdio.h>
#include<unistd.h>
#include<sys/sem.h>
#include<sys/ipc.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
	key_t key;
	int nsems,semflg,semid,semnum,cmd;
	size_t nsops;
	unsigned short semval;
	struct sembuf wait,signal;

		key=123456;
		nsems=1;
		semflg=0666|IPC_CREAT;
		
		wait.sem_num=0;
		wait.sem_op=-1;
		wait.sem_flg=SEM_UNDO;

		signal.sem_num=0;
		signal.sem_op=1;
		signal.sem_flg=SEM_UNDO;

	 if((semid=semget(key,nsems,semflg))<0)
		{
			perror("semid");
			exit(1);
		}
	
	
	   semval=0;
	  semctl(semid,0,SETVAL,semval);

	//get semaphore value
	semval=semctl(semid,0,GETVAL);
	printf("semValue=%d",semval);

	int i=0,cnt=5;

	int c=fork();

	if(c==0)
	{
		//setting semphore value to 1 
	         semval=1;
	       semctl(semid,0,SETVAL,semval);

		while(i<cnt)
		{
			semop(semid,&wait,1);
			semval=semctl(semid,0,GETVAL);
	           printf("\n1semValue=%d",semval);
			printf("\ni am child process\n");	
			semop(semid,&signal,1);
			usleep(100);
				i++;
		}
	
	}
	else
	{
		semval=semctl(semid,0,GETVAL);
	      printf("\n22semValue=%d",semval);
		while(i<cnt)
		{
			semop(semid,&wait,1);
			semval=semctl(semid,0,GETVAL);
	     		 printf("\n33semValue=%d",semval);
			printf("\ni am parenmt process\n");	
			semop(semid,&signal,1);
			usleep(100);
			i++;
		}
		//wait(NULL);	
	}
	semctl(semid,0,IPC_RMID);
	return 0;
}
